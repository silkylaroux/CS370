README
======

This package includes the following files.

|-- Scheduler.c [This is the driver program which will take the input create arrival times to be parsed into scheduling data]
|-- Makefile [For compiling, cleaning and taring].
|-- README.txt [This file]
